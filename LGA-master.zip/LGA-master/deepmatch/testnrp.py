import matlab.engine
from deepmatch.initialMatching import *
from eval.graph_util import *
from ProNe.proNE import ProNE
def const(n,isdirected,input_graph):
    edges = {i: [] for i in range(n)}
    with open(input_graph, 'r') as fin:
        for line in fin:
            u, v = line.split()
            u, v = int(u), int(v)
            edges[u].append(v)
            if isdirected == False:
                edges[v].append(u)
    print("writing " + 'outdegreelist.txt' )
    with open('../../algos/nrp/outdegreelist.txt', 'w') as fout:
        for i in range(n):
            for j in edges[i]:
                deginv = 1.0 / (len(edges[i]))
                fout.write(str(i) + " " + str(j) + " " + str(deginv) + "\n")
    print("writing " + 'outdegree.txt')
    with open('../../algos/nrp/outdegree.txt', 'w') as fout:
        for i in range(n):
            fout.write(str(i) + " " + str((len(edges[i]))) + "\n")



inptut_graph="../data1/ppi.txt"
G =load_file(inptut_graph,False)
G=get_subgraph(G, 500)
Gaa=nx.Graph()
G=nx.disjoint_union(G,Gaa)
G1=G
nx.write_edgelist(G,"test.txt",data=False)
const(500,False,"test.txt")

nodes = 500 / 1.0


engine = matlab.engine.start_matlab()
engine.test(nodes, "test.txt", nargout=0)
engine.nrp("ppi", 1, 1, d, 20, 10, nargout=0)
Embeddding("ppi", NRP, d, nodes, True)
model = ProNE("test.txt", '../blo1.emb', '../blo2.emb', d)
features_matrix = np.loadtxt("../blo1.emb")


engine.test(nodes, "test.txt", nargout=0)
engine.nrp("ppi", 1, 1, d, 20, 10, nargout=0)
Embeddding("ppi", NRP, d, nodes, True)
model = ProNE("test.txt", '../blo1.emb', '../blo2.emb', d)
features_matrix2 = np.loadtxt("../blo1.emb")

reg = RigidRegistration.RigidRegistration(features_matrix, features_matrix2)
callback = partial(visualize)
reg.register(callback)
proM = reg.P
M, N = proM.shape


values = [(i, j, 1 - proM[i][j])
          for i in range(M)
          for j in range(N) if proM[i][j] > 1e-2]
values_dict = dict(((i, j), v) for i, j, v in values)
munkres_match = munkres(values)
matches = []
for p1, p2 in munkres_match:
    if p1 > M or p2 > N:
        continue
    else:
        matches.append((int(p1), int(p2), 1 - values_dict[(p1, p2)]))

matches_ms=bipartite_matching(G, G1)
print("done")
sc=0
for i in matches_ms:
    print(matches_ms[0])
    if matches_ms[0]==matches_ms[1]:
        sc=sc+1
print(sc/len(matches_ms))