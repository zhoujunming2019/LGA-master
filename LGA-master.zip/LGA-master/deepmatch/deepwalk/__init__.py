# -*- coding: utf-8 -*-

__author__ = 'Bryan Perozzi'
__email__ = 'bperozzi@cs.stonybrook.edu'
__version__ = '1.0.0'
