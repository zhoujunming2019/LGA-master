function [] = test(nodes,graph)



directed=1;
%1��������ͼ
outdegree_list  = load(graph);
A = sparse(outdegree_list(:,1)+1,outdegree_list(:,2)+1,1, nodes, nodes);
if directed>0
    B= sparse(outdegree_list(:,2)+1,outdegree_list(:,1)+1,1, nodes, nodes);
    A=A+B;
end
%load('mydata.mat');
save b A
outdegree_list=load('D:\netalign\algos\nrp\outdegree.txt');
Dout = sparse(1, outdegree_list(:,1)+1, outdegree_list(:,2), 1, nodes);
save b1 Dout
outdegree_list=load('D:\netalign\algos\nrp\outdegreelist.txt');
P=sparse(outdegree_list(:,1)+1, outdegree_list(:,2)+1,outdegree_list(:,3), nodes, nodes);

save b2 P