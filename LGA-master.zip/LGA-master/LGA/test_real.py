import matlab.engine
from deepmatch.new_graph import *
from deepmatch.initialMatching import main
from deepmatch.constru_graph import *
from deepmatch.aline import run as runs
from deepmatch.new_graph import combin_graph as combin_graph2
from eval.graph_util import *
from networkx.readwrite import json_graph
import json
sample = [0.99]
repeat=1


inptut_graph1="../../flickr_myspace/flickr/graphsage/G.json"
inptut_graph2="../../flickr_myspace/myspace/graphsage/G.json"
id2idx_file1="../../douban/id2idx_online.json"
id2idx_file2="../../douban/id2idx_offline.json"


def _load_G(input):
    G_data = json.load(open(input))
    G = json_graph.node_link_graph(G_data)

    # if type(G.nodes()[0]) is int:
    #     mapping = {k: str(k) for k in G.nodes()}
    #     G = nx.relabel_nodes(G, mapping)
    return G
G1=_load_G(inptut_graph1)

G2=_load_G(inptut_graph2)

# id1 = {}
# id2idx1 = json.load(open(id2idx_file1))
# for k, v in id2idx1.items():
#     k=int(k)
#     id1[k] = v
# id2 = {}
# id2idx2 = json.load(open(id2idx_file2))
# for k, v in id2idx2.items():
#     k = int(k)
#     id2[k] = v

list1=[]
groundtruth="../../flickr_myspace/dictionaries/groundtruth"
with open(groundtruth, 'r') as fin:
    for line in fin:
        u, v = line.split()
        u, v = int(u), int(v)
        list1.append((u,v))
# print(list1)
for i in sample:
    score_count = 0.0

    for j in range(repeat):
        G11 = get_subgraph(G1, 500)
        GC1 = max((G11.subgraph(c1) for c1 in nx.connected_components(G11)), key=len)
        G22 = get_subgraph(G2, 500)
        GC2 = max((G22.subgraph(c1) for c1 in nx.connected_components(G22)), key=len)
        matches_ms = bipartite_matching(GC1, GC2)


        for match in matches_ms:
            # 匹配列表中g2的点

            this=(match[0],match[1])
            # print(this)
            this1 = (match[1], match[0])
            if this  in list1:
                print("匹配")
            if this1  in list1:
                print("匹配")
            # if id1[match[0]] == id2[match[1]]:
            #     print("匹配")
            # # else:
            #     continue
        # print(len(nodes_g2))
        # print(nodes_match)


    #     nodes = GC1.nodes()
    #     nodes = list(nodes)
    #     nodes.sort()
    #     print(nodes)
    #     nodes_num = len(nodes)
    #     print("采样节点数：" + str(nodes_num))
    #
    #     f = open(out_graph, 'w')
    #     with open(inptut_graph, 'r') as fin:  # 原图
    #         for line in fin:
    #             f.writelines(line)
    #             u, v = line.split()
    #             u, v = int(u), int(v)
    #             if u in nodes and v in nodes:
    #                 continue
    #             if u not in nodes:
    #                 u = tag(nodes, u, nodes_num, G.number_of_nodes())
    #             if v not in nodes:
    #                 v = tag(nodes, v, nodes_num, G.number_of_nodes())
    #             f.writelines(str(u) + " " + str(v) + "\n")
    #
    #     f.close()
    #     G_new = load_file(out_graph)
    #     # nodes = combin_graph("../../data1/Cit-hepPh.txt", i, 500, "../../aline_true.txt", "../../data1/combin_Cit-hepPh.txt",False)
    #
    #     #之间预对齐
    #     # nodes=combin_graph2("../../data1/CA-AstroPh.txt", i, 500, "../../aline_true.txt", "../../data1/combin_CA-AstroPh.txt",False)
    #     # 转化成matlab格式需求
    #     G = load_file(inptut_graph, False)
    #
    #     nodes = nodes / 1.0
    #     engine = matlab.engine.start_matlab()
    #     engine.test(nodes, nargout=0)
    #     engine.nrp('Email-Enron', 1, 1, 128, 20, 10, nargout=0)
    #     Embeddding('Email-Enron', NRP, 128, nodes, True)
    #     score= runs("../blo1.emb", "../../aline_true.txt")
    #     score_count = score + score_count
    # print("-----------------------------------------采样比例为：%f ----------------" % i)
    # print("*****************************************score  %f" % (score_count / repeat))
