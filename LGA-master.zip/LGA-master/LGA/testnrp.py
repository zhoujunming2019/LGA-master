import matlab.engine
from deepmatch.initialMatching import *
from eval.graph_util import *
from ProNe.proNE import ProNE
def const(n,isdirected,input_graph):
    edges = {i: [] for i in range(n)}
    with open(input_graph, 'r') as fin:
        for line in fin:
            u, v = line.split()
            u, v = int(u), int(v)
            edges[u].append(v)
            if isdirected == False:
                edges[v].append(u)
    print("writing " + 'outdegreelist.txt' )
    with open('../../algos/nrp/outdegreelist.txt', 'w') as fout:
        for i in range(n):
            for j in edges[i]:
                deginv = 1.0 / (len(edges[i]))
                fout.write(str(i) + " " + str(j) + " " + str(deginv) + "\n")
    print("writing " + 'outdegree.txt')
    with open('../../algos/nrp/outdegree.txt', 'w') as fout:
        for i in range(n):
            fout.write(str(i) + " " + str((len(edges[i]))) + "\n")

nodes1=555

inptut_graph="../../data1/Email-Enron.txt"
G =load_file(inptut_graph,False)
G=get_subgraph(G, nodes1)
G = max((G.subgraph(c1) for c1 in nx.connected_components(G)), key=len)
Gaa=nx.Graph()
G=nx.disjoint_union(G,Gaa)
G1=G

nodes1=G.order()
nodes = nodes1 / 1.0
nx.write_edgelist(G,"test.txt",data=False)
const(nodes1,False,"test.txt")

d=80



engine = matlab.engine.start_matlab()
engine.test(nodes, "test.txt", nargout=0)
engine.nrp("ppi", 1, 1, d, 20, 10, nargout=0)
Embeddding("ppi", NRP, d, nodes, True)
model = ProNE("test.txt", '../blo1.emb', '../blo2.emb', d)
features_matrix = np.loadtxt("../blo1.emb")
embeddings_matrix = model.chebyshev_gaussian(model.matrix0, features_matrix, 20, 0.2, 0.5)


engine.test(nodes, "test.txt", nargout=0)
engine.nrp("ppi", 1, 1, d, 20, 10, nargout=0)
Embeddding("ppi", NRP, d, nodes, True)
model = ProNE("test.txt", '../blo1.emb', '../blo2.emb', d)
features_matrix = np.loadtxt("../blo1.emb")
embeddings_matrix2 = model.chebyshev_gaussian(model.matrix0, features_matrix, 20, 0.2, 0.5)

print("aaa")
reg = RigidRegistration.RigidRegistration(embeddings_matrix, embeddings_matrix2)
print("done")
callback = partial(visualize)
print("done1")
reg.register(callback)
print("done2")
proM = reg.P
print("done3")
M, N = proM.shape
print("done4")

values = [(i, j, 1 - proM[i][j])
          for i in range(M)
          for j in range(N) if proM[i][j] > 1e-2]
values_dict = dict(((i, j), v) for i, j, v in values)
munkres_match = munkres(values)
matches = []
for p1, p2 in munkres_match:
    if p1 > M or p2 > N:
        continue
    else:
        matches.append([int(p1), int(p2)])

print(matches)
sc=0
for i in matches:

    if i[0]==i[1]:
        sc=sc+1
print(sc/nodes1)