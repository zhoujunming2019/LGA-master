from deepmatch.DeepMatching import *
from deepmatch.initialMatching import *
import matlab.engine
def tag(list1,num):#list1采样列表，num当前节点编号，sample，采样数量，n原图节点
    return list1.index(num)

#写入outdegreelist和outdegree文件
def const(n,isdirected,input_graph):
    edges = {i: [] for i in range(n)}
    with open(input_graph, 'r') as fin:
        for line in fin:
            u, v = line.split()
            u, v = int(u), int(v)
            edges[u].append(v)
            if isdirected == False:
                edges[v].append(u)
    print("writing " + 'outdegreelist.txt' )
    with open('../../algos/nrp/outdegreelist.txt', 'w') as fout:
        for i in range(n):
            for j in edges[i]:
                deginv = 1.0 / (len(edges[i]))
                fout.write(str(i) + " " + str(j) + " " + str(deginv) + "\n")
    print("writing " + 'outdegree.txt')
    with open('../../algos/nrp/outdegree.txt', 'w') as fout:
        for i in range(n):
            fout.write(str(i) + " " + str((len(edges[i]))) + "\n")

def combin_biggraph_final(inptut_graph,ratio,sample_nodes):
    #True代表无向图
    G =load_file(inptut_graph,False)
    G1_sample = sample_graph(G, ratio)
    print("破坏后图中节点：" + str(G1_sample.number_of_nodes()))
    G2 = get_subgraph(G1_sample, sample_nodes)
    GC2 = max((G2.subgraph(c1) for c1 in nx.connected_components(G2)), key=len)
    G1 = get_subgraph(G, sample_nodes)
    GC1 = max((G1.subgraph(c1) for c1 in nx.connected_components(G1)), key=len)
    edges2 = GC2.edges()

    edges1 = GC1.edges()
    nodes=list(GC1.nodes())
    dict1 = {}
    s = 0
    for i in nodes:
        dict1[i] = s
        s = s + 1
    f = open("testnrp_graph", 'w')
    for i in edges1:
        u=i[0]
        v=i[1]
        f.writelines(str(dict1[u])+" "+str(dict1[v])+"\n")

    f.close()



combin_biggraph_final("../../data1/youtu_subgraph",0.99,1000)
# const(1000,False,"testnrp_graph")
# nodes = 1000 / 1.0
# engine = matlab.engine.start_matlab()
# engine.test(nodes, "testnrp_graph", nargout=0)
# engine.nrp("ppi", 1, 1, 60, 20, 10, nargout=0)
# # Embeddding(graph_name, NRP, d, nodes, True)
sample_nodes=1000
input_graph = "../../data1/youtu_subgraph"
G = load_file(input_graph, False)
G1_sample = sample_graph(G, 0.99)
G2 = get_subgraph(G1_sample, sample_nodes)
GC2 = max((G2.subgraph(c1) for c1 in nx.connected_components(G2)), key=len)
G1 = get_subgraph(G, sample_nodes)
GC1 = max((G1.subgraph(c1) for c1 in nx.connected_components(G1)), key=len)
edges1 = GC1.edges()
nodes1 = list(GC1.nodes())
dict1 = {}
s = 0
for i in nodes1:
    dict1[i] = s
    s = s + 1
f = open("yuantu", 'w')
for i in edges1:
    u = i[0]
    v = i[1]
    f.writelines(str(dict1[u]) + " " + str(dict1[v]) + "\n")
f.close()
edges2 = GC2.edges()
nodes2 = list(GC2.nodes())
dict2 = {}
s = 0
for i in nodes2:
    dict2[i] = s
    s = s + 1
f = open("mubiaotu", 'w')
for i in edges2:
    u = i[0]
    v = i[1]
    f.writelines(str(dict2[u]) + " " + str(dict2[v]) + "\n")
f.close()
f = open("nrp_line", 'w')
for i in nodes2:
    f.writelines(str(dict1[i]) + " " + str(dict2[i]) + "\n")
f.close()