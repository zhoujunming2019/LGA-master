import matlab.engine
from deepmatch.new_graph import *
from deepmatch.initialMatching import main
from deepmatch.constru_graph import *
from deepmatch.aline import run as runs
from deepmatch.aline import run_final
from deepmatch.aline import run_new

from deepmatch.new_graph import combin_graph as combin_graph2
from eval.graph_util import *
# from deepmatch.constru_graph_final import combin_graph_final
from deepmatch.constru_biggraph_final import combin_biggraph_final
from deepmatch.constru_biggraph_final import combin_biggraph_true
from ProNe.proNE import ProNE
from deepmatch.initialMatching import nodes_embedding
sample = [0.99,0.98,0.97,0.96]
sample = [0.95]

dimension=[20,40,60,80,100,120,140,160,180]
dimension=[80]
repeat=1
for d in dimension:
    for i in sample:
        score_count = 0.0
        seedtime_count=0
        for j in range(repeat):
            # nodes = combin_graph("../../data1/ppi.txt", i, 500, "../../aline_true.txt", "../../data1/combin_ppi.txt",False)
            input_graph = "../../data1/blocat.txt"
            output_graph = "../../data1/combin_dblp.txt"
            graph_name = 'ppi'

            nodes = combin_biggraph_final(input_graph, i, 808, "../../aline_true.txt", output_graph, False)            # 转化成matlab格式需求

            # nodes = combin_graph_final(input_graph, i, 808, "../../aline_true.txt", output_graph, False)            # 转化成matlab格式需求
            # nodes,seed_time = combin_biggraph_true(input_graph, i, 1532, "../../aline_true.txt", output_graph, False)
            nodes = nodes / 1.0
            G1=nx.read_edgelist(output_graph)
            nodes1, embeddings_matrix = nodes_embedding(G1, p=1, q=1, dimensions=80, embedding='DeepWalk')
            # engine = matlab.engine.start_matlab()
            # engine.test(nodes, output_graph, nargout=0)
            # engine.nrp(graph_name, 1, 1, d, 20, 10, nargout=0)
            # Embeddding(graph_name, NRP, d, nodes, True)
            # model = ProNE(output_graph, '../blo1.emb', '../blo2.emb', d)
            # features_matrix = np.loadtxt("../blo1.emb")
            # embeddings_matrix = model.chebyshev_gaussian(model.matrix0, features_matrix, 20, 0.2, 0.5)
            # score = run_final(embeddings_matrix, "../../aline_true.txt")
            score = run_new(embeddings_matrix, "../../aline_true.txt")
            score_count = score + score_count
            # seedtime_count=seedtime_count+seed_time
        print("维度为 %f" %d)
        print("-----------------------------------------采样比例为：%f ----------------" % i)
        print("*****************************************score  %f" % (score_count / repeat))
        # print("*****************************************time  %f" % (seedtime_count / repeat))
