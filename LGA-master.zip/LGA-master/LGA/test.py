# coding=UTF-8
import matlab.engine
from deepmatch.new_graph import *
from deepmatch.initialMatching import main
from deepmatch.constru_graph import *
from deepmatch.aline import run as runs
from deepmatch.new_graph import combin_graph as combin_graph2
from eval.graph_util import *
from deepmatch.constru_graph_final import combin_graph_final
from ProNe.proNE import ProNE
sample = [0.99, 0.98, 0.97, 0.96,0.95, 0.90, 0.85, 0.80]
repeat=4
for i in sample:
    score_count = 0.0

    for j in range(repeat):
        # nodes = combin_graph("../../data1/ppi.txt", i, 500, "../../aline_true.txt", "../../data1/combin_ppi.txt",False)
        input_graph = "../../data1/ppi.txt"
        output_graph = "../../data1/combin_ppi.txt"
        graph_name = 'Email-Enron'
        #之间预对齐
        nodes=combin_graph2(input_graph, i, 195, "../../aline_true.txt", output_graph,False)

        nodes = combin_graph_final(input_graph, i, 500, "../../aline_true.txt", output_graph, False)
        # 转化成matlab格式需求
        nodes = nodes / 1.0
        engine = matlab.engine.start_matlab()
        engine.test(nodes, output_graph, nargout=0)
        engine.nrp(graph_name, 1, 1, 128, 20, 10, nargout=0)
        Embeddding(graph_name, NRP, 128, nodes, True)
        score = runs("../blo1.emb", "../../aline_true.txt")
        score_count = score + score_count
    print("-----------------------------------------采样比例为：%f ----------------" % i)
    print("*****************************************score  %f" % (score_count / repeat))
